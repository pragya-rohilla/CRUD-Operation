import React from "react";

const UserTable = (props) => (
  <table>
    <thead>
      <tr>
        <th>Product</th>
        <th>Description</th>
        <th>Price</th>
        <th>Offer Price</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      {props.users.length > 0 ? (
        props.users.map((user) => (
          <tr key={user.id}>
            <td>{user.productName}</td>
            <td>{user.productDescription}</td>
            <td>{user.price}</td>
            <td>{user.offerPrice}</td>
            <td>
              <button
                className="btn btn-outline-primary mr-2"
                onClick={() => props.editRow(user)}
              >
                Edit
              </button>
              <button
                className="btn btn-outline-danger"
                onClick={() => props.deleteUser(user.id)}
              >
                Delete
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={3}>No Product</td>
        </tr>
      )}
    </tbody>
  </table>
);

export default UserTable;

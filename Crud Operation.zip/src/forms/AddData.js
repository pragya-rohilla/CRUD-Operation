import React, { useState } from "react";

const AddUserForm = (props) => {
  const initialFormState = {
    id: null,
    productName: "",
    productDescription: "",
    price: "",
    offerPrice: ""
  };
  const [user, setUser] = useState(initialFormState);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (
          !user.productName ||
          !user.productDescription ||
          !user.price ||
          !user.offerPrice
        )
          return;
        props.addUser(user);
        setUser(initialFormState);
      }}
    >
      <label>Product</label>
      <br />
      <input
        type="text"
        name="productName"
        value={user.productName}
        onChange={handleInputChange}
      />
      <br />
      <label>Description</label>
      <br />
      <input
        type="text"
        name="productDescription"
        value={user.productDescription}
        onChange={handleInputChange}
      />
      <br />

      <label>Price</label>
      <input
        type="text"
        name="price"
        value={user.price}
        onChange={handleInputChange}
      />
      <br />

      <label>Offer Price</label>
      {/* <input
        type="text"
        name="Offerprice"
        value={user.Offerprice}
        onChange={handleInputChange}
      /> */}
      <input
        type="text"
        name="offerPrice"
        value={user.offerPrice}
        onChange={handleInputChange}
      />
      <br />
      <button className="btn  btn-primary mt-2 mb-2">Add new Product</button>
    </form>
  );
};

export default AddUserForm;

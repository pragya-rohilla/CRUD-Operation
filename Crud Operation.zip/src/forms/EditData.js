import React, { useState, useEffect } from "react";

const EditData = (props) => {
  const [user, setUser] = useState(props.currentUser);

  useEffect(() => {
    setUser(props.currentUser);
  }, [props]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        props.updateUser(user.id, user);
      }}
    >
      <label>Product</label>
      <input
        type="text"
        name="productName"
        value={user.productName}
        onChange={handleInputChange}
      />
      <label>Description</label>
      <input
        type="text"
        name="productDescription"
        value={user.productDescription}
        onChange={handleInputChange}
      />

      <br />
      <label>Price</label>
      <input
        type="text"
        name="price"
        value={user.price}
        onChange={handleInputChange}
      />

      <br />
      <label>Offer Price</label>
      <input
        type="text"
        name="offerPrice"
        value={user.offerPrice}
        onChange={handleInputChange}
      />
      <br />
      <button className="btn btn-success mt-2 mb-2 mr-2">Update Product</button>
      <button
        onClick={() => props.setEditing(false)}
        className="btn btn-danger mt-2 mb-2 mr-2"
      >
        Cancel
      </button>
    </form>
  );
};

export default EditData;

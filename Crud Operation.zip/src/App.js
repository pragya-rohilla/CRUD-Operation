import React, { useState } from "react";
import UserTable from "./view/ViewData";
import AddUserForm from "./forms/AddData";
import EditUserForm from "./forms/EditData";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import "./styles.css";
import Pagination from "./Pagination/Pagination";
const App = () => {
  const usersData = [
    {
      id: 1,
      productName: "Product A",
      productDescription: "Lorum ipsum",
      price: "44$",
      offerPrice: "30$"
    },
    {
      id: 2,
      productName: "Product B",
      productDescription: "Lorum ipsum",
      price: "44$",
      offerPrice: "30$"
    },

    {
      id: 3,
      productName: "Product C",
      productDescription: "Lorum ipsum",
      price: "44$",
      offerPrice: "30$"
    }
  ];

  const sortByAge = () => {
    alert("hi");
    // const sorted = [...users].sort((a, b) => {
    //   return b.name - a.name;
    // });
    // setUsers(sorted);
    // //alert(sorted[0].name);
  };

  const [users, setUsers] = useState(usersData);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(2);

  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  // console.log(posts);
  const currentPosts = users.slice(indexOfFirstPost, indexOfLastPost);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const addUser = (user) => {
    user.id = users.length + 1;

    setUsers([...users, user]);
  };

  const deleteUser = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  const [editing, setEditing] = useState(false);
  const initialFormState = {
    id: null,
    productName: "",
    productDescription: "",
    price: "",
    offerPrice: ""
  };

  const [currentUser, setCurrentUser] = useState(initialFormState);

  const editRow = (user) => {
    setEditing(true);
    setCurrentUser({
      id: user.id,
      productName: user.productName,
      productDescription: user.productDescription,
      price: user.price,
      offerPrice: user.offerPrice
    });
  };

  const updateUser = (id, updateUser) => {
    setEditing(false);
    setUsers(users.map((user) => (user.id === id ? updateUser : user)));
  };

  return (
    <div className="fluid-container">
      <h1 className="bg-dark text-white">CRUD OPERATIONS</h1>
      <div className="container-cus">
        <div className="d-flex card col-lg-12 mt-4">
          {editing ? (
            <div>
              <h2>Edit Product</h2>
              <EditUserForm
                editing={editing}
                setEditing={setEditing}
                currentUser={currentUser}
                updateUser={updateUser}
              />
            </div>
          ) : (
            <div>
              <div className="add">
                <h2>Add Product</h2>
                <AddUserForm addUser={addUser} />
              </div>
            </div>
          )}
        </div>
        <div className="card col-lg-12 mt-4 mb-4">
          <h2>View Product</h2>
          <UserTable
            users={currentPosts}
            deleteUser={deleteUser}
            editRow={editRow}
          />
        </div>
        <Pagination
          postsPerPage={postsPerPage}
          totalPosts={users.length}
          paginate={paginate}
        />
      </div>
    </div>
  );
};

export default App;
